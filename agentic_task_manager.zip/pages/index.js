
import { useState, useEffect } from "react";
import axios from "axios";

export default function Home() {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState("");

  useEffect(() => {
    axios.get("http://localhost:5000/api/tasks").then((res) => setTasks(res.data));
  }, []);

  const addTask = async () => {
    const res = await axios.post("http://localhost:5000/api/tasks", { title: newTask });
    setTasks([...tasks, res.data]);
    setNewTask("");
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-4">
      <h1 className="text-2xl font-bold mb-4">Agentic Task Manager</h1>
      <div className="flex mb-4">
        <input
          className="border p-2 mr-2 rounded"
          placeholder="New task"
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
        />
        <button className="bg-blue-500 text-white px-4 py-2 rounded" onClick={addTask}>
          Add Task
        </button>
      </div>
      <ul className="w-full max-w-md">
        {tasks.map((task) => (
          <li key={task._id} className="bg-white p-2 my-1 rounded shadow">
            {task.title}
          </li>
        ))}
      </ul>
    </div>
  );
}
