
# Agentic Task Manager

A simple full-stack task management app built with Next.js (frontend), Tailwind CSS (styling), Node.js + Express (backend), and MongoDB (database).

## Features

✅ Add new tasks  
✅ View all tasks  
✅ Modular React + Next.js components  
✅ RESTful API with Express  
✅ MongoDB for persistent storage  
✅ Tailwind CSS for clean, responsive UI

## Tech Stack

- **Frontend:** Next.js, React, Tailwind CSS
- **Backend:** Node.js, Express
- **Database:** MongoDB
- **API Client:** Axios

## Setup

1. Run `npm install` in both frontend and backend directories
2. Run backend: `node server.js`
3. Run frontend: `npm run dev`

## API

- `GET /api/tasks` - fetch tasks
- `POST /api/tasks` - create a task
